import React from 'react'
import s from './PerProduct.module.scss'
import { Link } from 'react-router-dom'
import { Paths } from '../../routes/paths'
import CustomBtn from '../UI/CustomBtn'
import { basketIcon, productImg, starIcon } from '../../utils'

const PerProduct = () => {
  return (
    <div className={s.product}>
        <div className={s.product__nav}>
            <Link to={Paths.menu} className={s.product__link}>{'<'}</Link>
            <h1 className={s.product__title}>Наслаждение</h1>
            <CustomBtn
                text='В корзину'
                icon={basketIcon}
                width={143}
                height={43}
                isActive={true}
            />
        </div>
        <div className={s.product__content}>
            <img src={productImg} alt="" className={s.product__img} />
            <div className={s.product__info}>
                <div className={s.product__card}>
                    <h3>Цена</h3>
                    <p>300 <span>₽</span></p>
                </div>
                <div className={s.product__card}>
                    <h3>Рейтинг</h3>
                    <div className={s.product__rating}>
                        4.5
                        <img src={starIcon} alt="" />
                    </div>
                </div>
                <p className={s.product__desc}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque sapiente iste ducimus eos ad enim mollitia consectetur. Ad, ullam earum!</p>
            </div>
        </div>
    </div>
  )
}

export default PerProduct