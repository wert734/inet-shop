import React, { FC } from 'react'
import { FieldError, FieldErrorsImpl, Merge, UseFormRegisterReturn } from 'react-hook-form'

interface ICustomInputProps {
  register: UseFormRegisterReturn;
  errors: FieldError | Merge<FieldError, FieldErrorsImpl<any>> | undefined;
  label: string;
  type: string;
  holder: string;
}

const CustomInput:FC<ICustomInputProps> = ({register, errors, label, type, holder}) => {
  return (
    <div className="enter__item">
      <label>
        <span className="enter__text">{label}</span>
        <input type={type}
          className="enter__input"
          placeholder={holder}
          {...register} />
      </label>
      <p className="enter__error">
        {errors && <>{errors.message}</>}
      </p>
    </div>
  )
}

export default CustomInput