import React from 'react'
import UserLayout from '../layouts/UserLayout'

const Cart = () => {
  return (
    <UserLayout>
      <div>Cart</div>
    </UserLayout>
  )
}

export default Cart