export const Paths = {
    menu: '/',
    login: '/login',
    register: '/register',
    cart: '/cart',
    profile: '/profile',
    menuProduct: '/product/:id',
    product: '/product/'
} as const


