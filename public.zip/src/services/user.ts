import { ILogin, IRegister } from "../types";
import api from "./api";
import { useQuery, useMutation } from "@tanstack/react-query";

export const useRegisterMutation = ()=>{
    return useMutation({
        mutationFn: (useData: IRegister)=> api.post('/auth/register', useData)
    })
}

export const userLoginMutation = ()=>{
    return useMutation({
        mutationFn: (useData: ILogin)=> api.post('/auth/login', useData),
        onSuccess: ( {data} )=>{
            if(data && data.access) {
                localStorage.setItem('access_token', data.access);
                localStorage.setItem('refresh_token', data.refresh);
            }
            console.log(data);
        }
    })
}

export const useCurrentUser = ()=>{
    const accessToken = localStorage.getItem('access_token')
    return useQuery({
        queryKey: ['current'],
        queryFn: ()=> api.get('/auth/users/profile'),
        enabled: !!accessToken,
        select: (data)=> data.data
    })
}